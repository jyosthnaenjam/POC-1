import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  registrationForm!: FormGroup;
  usersList: Array<Object> = []
  submitted = false;
  imagePath = 'assets/image.png';
  imageWidth = 700; 
  imageHeight = 800;
  countries: string[] = ['Select Country', 'India','USA', 'Canada', 'UK', 'Australia', 'Other'];
  states: string[] = ['Select State','Telangana','Andhra Pradesh','Karnataka','Tamil Nadu','Himachal Pradesh']
  constructor(private fb: FormBuilder,private router: Router) { }

  ngOnInit(): void {
    // this.usersList =  JSON.parse(localStorage.getItem('list') as any) || [];
    // console.log(this.usersList)
    this.registrationForm = this.fb.group({
      // username: ['', [Validators.required, Validators.minLength(3)]],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      phoneNumber: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      email: ['', [Validators.required, Validators.email]],
      country: ['Select Country', [Validators.required]],
      state: ['Select State', [Validators.required]],
      dob: [null, [Validators.required]],
      address: ['', [Validators.required, Validators.pattern(/^[\w\d\s\/-]+$/)]],
      zipcode: ['', [Validators.required, Validators.pattern(/^\d{5}$/)]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required],

    }, {
      validators: this.passwordMatchValidator
    });
  }

  passwordMatchValidator(form: FormGroup) {
    const password = form.get('password')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;

    return password === confirmPassword ? null : { mismatch: true };
  }

  onSubmit() {
    console.log('Saving user details...');
  this.submitted = true;
    // this.submitted = true;
    console.log('Form validity:', this.registrationForm.valid);
  
  if (this.registrationForm.invalid) {
    console.log('Form is invalid. Cannot submit.');
    return;
    }
    this.usersList.push(this.registrationForm.value)
    localStorage.setItem('list', JSON.stringify(this.usersList))
    this.router.navigate(['/login'])
  }
  // title = "Registration Form";
  // userDetails!: FormGroup;
  // submitted = false;
  // usersList: Array<Object> = []
  // constructor(private router: Router) { }

  // ngOnInit(): void {
  //   this.userDetails = new FormGroup({
  //     name: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(15)]),
  //     //  lastName: new FormControl('',Validators.required),
  //     email: new FormControl('', Validators.required),
  //     gender: new FormControl('', Validators.required),

  //     //  course: new FormControl(Validators.required),
  //     //  accept: new FormControl(false),
  //     //  reject: new FormControl(false)
  //   })
  // }
  // get f() {
  //   // console.log(this.userDetails.controls['name'])
  //   return this.userDetails.controls
  // }
  // saveUserDetails() {
  //   this.submitted = true;
  //   if(this.userDetails.invalid){
  //     console.log(this.userDetails.invalid +"add")
  //     return;
  //   }
  //   this.usersList.push(this.userDetails.value)
  //   localStorage.setItem('list', JSON.stringify(this.usersList))
  //   this.router.navigate(['/login'])
  // }
 
}
