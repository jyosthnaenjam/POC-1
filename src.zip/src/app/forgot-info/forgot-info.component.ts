import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-forgot-info',
  templateUrl: './forgot-info.component.html',
  styleUrls: ['./forgot-info.component.css']
})
export class ForgotInfoComponent {
    isOpen: boolean = false;
    email: any;
    myForm!: FormGroup;
    formGroup!: FormGroup;

    constructor(private fb: FormBuilder,private modalService: NgbModal,) {}
  
    ngOnInit(): void {
      this.myForm = this.fb.group({
        email: ['', [Validators.required, Validators.email]],
      accountNumber: ['', [Validators.required, Validators.pattern(/^[0-9]+$/)]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', Validators.required]
    }, {
      validators: this.passwordMatchValidator
    });
    }
    passwordMatchValidator(formGroup: FormGroup) {
      const password = formGroup.get('password')?.value;
      console.log(password)
      const confirmPassword = formGroup.get('confirmPassword')?.value;
  
      if (password !== confirmPassword) {
        formGroup.get('confirmPassword')?.setErrors({ mismatch: true });
      } else {
        formGroup.get('confirmPassword')?.setErrors({});
      }
    }
    onSubmit() {
      if (this.myForm.valid) {
        console.log('myForm')
        // Handle form submission
      }
    }
    openPopup() {
      this.isOpen = true;
    }
    closePopup() {
      this.modalService.dismissAll();
    }

}
