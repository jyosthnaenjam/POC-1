import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm!: FormGroup;
  imagePath = 'assets/image.png';
  imageWidth = 600; 
  imageHeight = 800;
  isShowPopup: boolean = false;
  email: any;
  submitted = false;
  username: string = '';
  password: string = '';
  constructor(private fb: FormBuilder,private router: Router,private modalService: NgbModal,) {}
  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.pattern(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/)]],
      password: ['', [Validators.required, Validators.pattern(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,16}$/)]],
    });
  }
 
  get formControls() {
    return this.loginForm.controls;
  }
  // onSubmit() {
  //   let getUsersList = JSON.parse(localStorage.getItem('list') as any)
  //   console.log(getUsersList)
  //   let index = getUsersList.findIndex((item: any) =>item['email']==this.email)
  //   if(index == -1){
  //     alert('user details not found!')
  //   }else{
  //     alert('successfuly logedin')
  //     // console.log("value",localStorage.setItem('isAuthenticate', JSON.stringify(true)))
  //     // localStorage.setItem('isAuthenticate', true)
  //     localStorage.setItem('isAuthenticate',JSON.stringify(true))
  //     this.router.navigate(['/forgot-info'])
  //   }
  // }
  onSubmit() {
    // Handle form submission and check authentication
    const storedUserData = localStorage.getItem('user');
    const formData = this.loginForm.value;

    if (storedUserData) {
      const storedUser = JSON.parse(storedUserData);
      if (
        formData.username === storedUser.username &&
        formData.password === storedUser.password
      ) {
        // Authentication successful
        console.log('Login successful');
      } else {
        // Authentication failed
        console.log('Login failed');
      }
    } else {
      // User not found
      console.log('User not found');
    }
  }
  openForgotPasswordPopup(content: any) {
    this.modalService.open(content, {
      centered: true,
      scrollable: true,
      size: 'lg',
      backdrop: 'static',
    });
    // Open the forgot password popup
    // this.router.navigateByUrl('/forgot-info');
    console.log("entered")
  }
  getRegistration(){
    this.router.navigate(['/registration']);
  }
  onLoginClick() {
    // Your login logic goes here

    // Clear the input fields
    // this.username = '';
    // this.password = '';
  }
}
